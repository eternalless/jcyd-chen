new Vue({
  el: '#app',
  data: {
    isLogin: true,
    isLost: false,
    isLostLogin: true,
    isCode: false,
    isCodeWrap: false,
    trademark: false,
    icon: false,
    isEdit: false,
    isSure: false,
    isSureButton: false,
    isDeleteSuccess: false,
    trademarkRadio: false,
    title: '',
    link: '',
    index: '',
    tags: [],
    newTag: '',
    size: 6,
    data: [
      {
        title: 'aaa',
        trademark: true,
        url: './imgs/1.jpeg',
        tags: ['#dog', '#animal'],
        link: 'ssssssssss'
      },
      {
        title: 'bbbb',
        trademark: false,
        url: './imgs/1.jpeg',
        tags: ['#dog', '#animal'],
        link: 'ssssssssss'
      },
      {
        title: 'cccc',
        trademark: true,
        url: './imgs/1.jpeg',
        tags: ['dog', 'animal'],
        link: 'ssssssssss'
      },
      {
        title: 'aaa',
        trademark: true,
        url: './imgs/1.jpeg',
        tags: ['#dog', '#animal'],
        link: 'ssssssssss'
      },
      {
        title: 'bbbb',
        trademark: false,
        url: './imgs/1.jpeg',
        tags: ['#dog', '#animal'],
        link: 'ssssssssss'
      },
      {
        title: 'cccc',
        trademark: true,
        url: './imgs/1.jpeg',
        tags: ['dog', 'animal'],
        link: 'ssssssssss'
      },
      {
        title: 'aaa',
        trademark: true,
        url: './imgs/1.jpeg',
        tags: ['#dog', '#animal'],
        link: 'ssssssssss'
      },
      {
        title: 'bbbb',
        trademark: false,
        url: './imgs/1.jpeg',
        tags: ['#dog', '#animal'],
        link: 'ssssssssss'
      },
      {
        title: 'cccc',
        trademark: true,
        url: './imgs/1.jpeg',
        tags: ['dog', 'animal'],
        link: 'ssssssssss'
      },
      {
        title: 'aaa',
        trademark: true,
        url: './imgs/1.jpeg',
        tags: ['#dog', '#animal'],
        link: 'ssssssssss'
      },
      {
        title: 'bbbb',
        trademark: false,
        url: './imgs/1.jpeg',
        tags: ['#dog', '#animal'],
        link: 'ssssssssss'
      },
      {
        title: 'cccc',
        trademark: true,
        url: './imgs/1.jpeg',
        tags: ['dog', 'animal'],
        link: 'ssssssssss'
      },
      {
        title: 'aaa',
        trademark: true,
        url: './imgs/1.jpeg',
        tags: ['#dog', '#animal'],
        link: 'ssssssssss'
      },
      {
        title: 'bbbb',
        trademark: false,
        url: './imgs/1.jpeg',
        tags: ['#dog', '#animal'],
        link: 'ssssssssss'
      },
      {
        title: 'cccc',
        trademark: true,
        url: './imgs/1.jpeg',
        tags: ['dog', 'animal'],
        link: 'ssssssssss'
      },
      {
        title: 'aaa',
        trademark: true,
        url: './imgs/1.jpeg',
        tags: ['#dog', '#animal'],
        link: 'ssssssssss'
      },
      {
        title: 'bbbb',
        trademark: false,
        url: './imgs/1.jpeg',
        tags: ['#dog', '#animal'],
        link: 'ssssssssss'
      },
      {
        title: 'cccc',
        trademark: true,
        url: './imgs/1.jpeg',
        tags: ['dog', 'animal'],
        link: 'ssssssssss'
      }
    ],
    imgBase64: '',
    img: false,
    isDelete: 'Re-upload',
    sure: '😳'
  },
  methods: {
    //登录时二维码隐藏
    hiddenCode() {
      let that = this
      this.isCode = !this.isCode
      setTimeout(function () {
        that.isCodeWrap = !that.isCodeWrap
      }, 500)
    },
    //登录时二维码点击
    showCode() {
      this.isCode = !this.isCode
      this.isCodeWrap = !this.isCodeWrap
    },
    //登录退出
    showLogin() {
      this.isLogin = false
      this.isLost = false
      this.isLostLogin = false
    },
    //是否展示找回密码
    showLost() {
      this.isLost = !this.isLost
      this.isLogin = !this.isLogin
    },
    //编辑信息按钮是否选中
    editRadio() {
      this.trademarkRadio = !this.trademarkRadio
    },
    //添加信息
    pushEdit() {
      this.isEdit = !this.isEdit
      if (this.index !== '') {
        let data = this.data[this.index]
        data.title = this.title
        data.link = this.link
        data.trademark = this.trademarkRadio
        data.tags = []
        for (let i in this.$refs.tag) {
          data.tags.push(this.$refs.tag[i].value)
        }
        data.tags.push(this.newTag)
        return
      }
      let newData = {
        title: this.title,
        trademark: this.trademarkRadio,
        url: './imgs/1.jpeg',
        tags: [this.newTag],
        link: this.link
      }
      this.data.unshift(newData)
    },
    //删除信息
    showDeleteSuccess() {
      var that = this
      this.isDeleteSuccess = !this.isDeleteSuccess
      this.isEdit = false
      this.isSure = false
      this.data.splice(this.index, 1)
      setTimeout(function () {
        that.isDeleteSuccess = !that.isDeleteSuccess
      }, 2000)
    },
    //编辑信息
    showEdit(index) {
      this.resetData()
      this.isEdit = !this.isEdit
      if (index === undefined) {
        this.img = false
        return
      }
      ;
      let data = this.data[index]
      this.title = data.title
      this.link = data.link
      this.trademarkRadio = data.trademark
      this.index = index
      this.tags = data.tags
      this.imgBase64 = data.url
      this.isDelete = 'Delete it'
      this.img = true
      let that = this
      setTimeout(function () {
        for (let i in that.tags) {
          console.log(that.tags[i])
          that.$refs.tag[i].value = that.tags[i]
        }
      }, 0)
    },
    //初始化数据
    resetData() {
      this.title = ''
      this.link = ''
      this.index = ''
      this.tags = []
      this.newTag = ''
      this.trademarkRadio = false
      this.isSure = false
      this.imgBase64 = ''
      this.isDelete = 'Re-upload'
    },
    //获取图片base64实现预览
    getImgBase() {
      var _this = this;
      var event = event || window.event;
      var file = event.target.files[0];
      var reader = new FileReader();
      //转base64
      reader.onload = function (e) {
        _this.imgBase64 = e.target.result;
      }
      console.log(file)
      this.img = !this.img
      reader.readAsDataURL(file);
    },
    //删除图片
    delImg() {
      if (this.index !== '') {
        this.showSure(0)
        return
      }
      this.imgBase64 = '';
      this.img = !this.img
    },
    //鼠标hover事件
    showNo() {
      this.sure = '🤗'
    },
    hiddenNo() {
      this.sure = '😳'
    },
    showYes() {
      this.sure = '😱'
    },
    //删除按钮动画效果
    showSure(index) {
      this.isSureButton = !this.isSureButton
      if (index) {
        var that = this
        setTimeout(function () {
          that.isSure = !that.isSure
        }, 200)
      } else {
        this.isSure = !this.isSure
      }

    },
  }
})